import { createContext, useContext, useEffect, useState } from "react";
import { ethers } from "ethers";
import useWallet from "../hooks/useWallet";
import contractService from "../services/contractService";

const WalletContext = createContext();

export const WalletProvider = ({ children }) => {
  const wallet = useWallet();

  const [balance, setBalance] = useState("0");
  const [contract, setContract] = useState(null);
  const [network, setNetwork] = useState("");
  const [contractReady, setContractReady] = useState(false);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const initialize = async () => {
      setInitializing(true);

      try {
        if (!wallet.isConnected) {
          setContract(null);
          setBalance("0");
          setNetwork("");
          setContractReady(false);
          return;
        }

        let provider = null;

        if (window.ethereum) {
          provider = new ethers.BrowserProvider(window.ethereum);

          const balanceWei = await provider.getBalance(
            wallet.walletAddress
          );

          setBalance(
            Number(
              ethers.formatEther(balanceWei)
            ).toFixed(4)
          );

          const networkInfo = await provider.getNetwork();

          setNetwork(networkInfo.name);
        }

        const contractInstance =
          await contractService.getContract();

        if (contractInstance) {
          setContract(contractInstance);
          setContractReady(true);
        } else {
          setContract(null);
          setContractReady(false);
        }
      } catch (error) {
        console.error(error);

        setContract(null);
        setContractReady(false);
      } finally {
        setInitializing(false);
      }
    };

    initialize();
  }, [wallet.walletAddress, wallet.isConnected]);

  return (
    <WalletContext.Provider
      value={{
        walletAddress: wallet.walletAddress,
        isConnected: wallet.isConnected,
        loading: wallet.loading || initializing,

        connectWallet: wallet.connectWallet,
        disconnectWallet: wallet.disconnectWallet,

        balance,
        network,

        contract,
        contractReady,

        setBalance,
        setNetwork,
        setContract,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export const useWalletContext = () => {
  const context = useContext(WalletContext);

  if (!context) {
    throw new Error(
      "useWalletContext must be used inside WalletProvider."
    );
  }

  return context;
};

export default WalletContext;