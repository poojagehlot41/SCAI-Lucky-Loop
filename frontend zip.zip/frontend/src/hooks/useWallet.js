import { useEffect, useState } from "react";
import { ethers } from "ethers";

const useWallet = () => {
  const [walletAddress, setWalletAddress] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [network, setNetwork] = useState("");
  const [loading, setLoading] = useState(false);

  const loadWallet = async () => {
    try {
      if (!window.ethereum) return;

      const provider = new ethers.BrowserProvider(window.ethereum);

      const accounts = await provider.send("eth_accounts", []);

      if (accounts.length > 0) {
        const networkData = await provider.getNetwork();

        setWalletAddress(accounts[0]);
        setNetwork(networkData.name);
        setIsConnected(true);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const connectWallet = async () => {
    try {
      if (!window.ethereum) {
        alert("Please install MetaMask.");
        return;
      }

      setLoading(true);

      const provider = new ethers.BrowserProvider(window.ethereum);

      const accounts = await provider.send(
        "eth_requestAccounts",
        []
      );

      const networkData = await provider.getNetwork();

      setWalletAddress(accounts[0]);
      setNetwork(networkData.name);
      setIsConnected(true);
    } catch (error) {
      console.error(error);

      setWalletAddress("");
      setNetwork("");
      setIsConnected(false);
    } finally {
      setLoading(false);
    }
  };

  const disconnectWallet = () => {
    setWalletAddress("");
    setNetwork("");
    setIsConnected(false);
  };

  useEffect(() => {
    loadWallet();

    if (!window.ethereum) return;

    const handleAccountsChanged = (accounts) => {
      if (accounts.length === 0) {
        disconnectWallet();
      } else {
        setWalletAddress(accounts[0]);
        setIsConnected(true);
      }
    };

    const handleChainChanged = () => {
      window.location.reload();
    };

    window.ethereum.on("accountsChanged", handleAccountsChanged);
    window.ethereum.on("chainChanged", handleChainChanged);

    return () => {
      window.ethereum.removeListener(
        "accountsChanged",
        handleAccountsChanged
      );

      window.ethereum.removeListener(
        "chainChanged",
        handleChainChanged
      );
    };
  }, []);

  return {
    walletAddress,
    isConnected,
    network,
    loading,
    connectWallet,
    disconnectWallet,
  };
};

export default useWallet;