const LotteryConfig = {

  CONTRACT_ADDRESS: "",

  NETWORK_NAME: "SCAI Mainnet",

  CHAIN_ID: "",

  CURRENCY: "SCAI",

};

export default LotteryConfig;