const LotteryABI = [];

export default LotteryABI;