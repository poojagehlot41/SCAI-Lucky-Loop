import {
  FaGithub,
  FaLinkedin,
  FaTelegramPlane,
  FaShieldAlt,
} from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container footer-container">
        <div className="footer-brand">
          <h2>SCAI Lucky Loop</h2>

          <p className="footer-description">
            Telegram Web3 Lottery Platform powered by SecureChain AI Mainnet,
            providing transparent, decentralized and secure lottery experiences
            through blockchain technology.
          </p>

          <div className="footer-meta">
            <p>
              <strong>Built by:</strong> Pooja Gehlot
            </p>

            <p>
              <strong>Organization:</strong> EtherAuthority
            </p>

            <p>
              <strong>Network:</strong> SecureChain AI Mainnet
            </p>
          </div>
        </div>

        <div className="footer-links">
          <h3>Quick Links</h3>

          <a href="/">Home</a>
          <a href="/lottery">Lottery</a>
          <a href="/wallet">Wallet</a>
          <a href="/referral">Referral</a>
          <a href="/profile">Profile</a>
        </div>

        <div className="footer-social">
          <h3>Community</h3>

          <div className="social-icons">
            <FaGithub />
            <FaLinkedin />
            <FaTelegramPlane />
          </div>

          <div className="footer-security">
            <FaShieldAlt />

            <span>Blockchain Secured</span>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2026 SCAI Lucky Loop. All Rights Reserved.</p>

        <p>
          Built for EtherAuthority Web3 Internship • Powered by SecureChain AI
        </p>
      </div>
    </footer>
  );
};

export default Footer;