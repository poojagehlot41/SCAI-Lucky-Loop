import { NavLink } from "react-router-dom";
import "../../styles/navbar.css";

function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar-container">
        <NavLink to="/" className="logo">
          <h2>SCAI Lucky Loop</h2>
          <span>Powered by EtherAuthority</span>
        </NavLink>

        <nav className="nav-links">
          <NavLink to="/">Home</NavLink>
          <NavLink to="/lottery">Lottery</NavLink>
          <NavLink to="/wallet">Wallet</NavLink>
          <NavLink to="/referral">Referral</NavLink>
          <NavLink to="/profile">Profile</NavLink>
          <NavLink to="/admin">Admin</NavLink>
        </nav>

        <button className="wallet-btn">
          Connect Wallet
        </button>
      </div>
    </header>
  );
}

export default Navbar;