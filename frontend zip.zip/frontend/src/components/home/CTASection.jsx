import Button from "../ui/Button";

const CTASection = () => {
  return (
    <section className="cta-section">
      <div className="container">

        <h2>Ready To Join SCAI Lucky Loop?</h2>

        <p>
          Connect your wallet, purchase your first lottery ticket,
          and experience transparent blockchain gaming.
        </p>

        <div className="hero-buttons">
          <Button>Connect Wallet</Button>

          <Button type="secondary">
            Buy Ticket
          </Button>
        </div>

      </div>
    </section>
  );
};

export default CTASection;