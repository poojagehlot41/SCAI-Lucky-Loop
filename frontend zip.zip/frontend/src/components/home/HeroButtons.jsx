import { FaWallet } from "react-icons/fa";
import { FaTicketAlt } from "react-icons/fa";

const HeroButtons = () => {
  return (
    <div className="hero-buttons">
      <button className="primary-btn">
        <FaWallet />
        Connect Wallet
      </button>

      <button className="secondary-btn">
        <FaTicketAlt />
        Buy Ticket
      </button>
    </div>
  );
};

export default HeroButtons;